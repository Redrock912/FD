// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "GM_Operator.generated.h"

/**
 * 
 */
UCLASS()
class TOPVIEW_API AGM_Operator : public AGameModeBase
{
	GENERATED_BODY()
	
	
	
	
};
