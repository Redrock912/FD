// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "PC_Operator.generated.h"

/**
 * 
 */
UCLASS()
class TOPVIEW_API APC_Operator : public APlayerController
{
	GENERATED_BODY()
	
	
	
	
};
